package com.cognizant.ridesharingplatform;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RidesharingplatformApplicationTests {

	@Test
	void contextLoads() {
	}

}
