package com.cognizant.ridesharingplatform.userverification.service;

public interface DrivinglicensesService {

}
