package com.cognizant.ridesharingplatform.vehiclemanagement.exceptions;

public class CustomException extends Exception {
	
	public CustomException(String exception) {
		super(exception);
	}

}
