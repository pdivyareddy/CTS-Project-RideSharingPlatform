package com.cognizant.ridesharingplatform.incidentmanagement.service;

import com.cognizant.ridesharingplatform.incidentmanagement.entities.InvestigationDetails;

public interface InvestigationDetailsService {
	InvestigationDetails addInvestigationReport(InvestigationDetails investigationDetails);

}
