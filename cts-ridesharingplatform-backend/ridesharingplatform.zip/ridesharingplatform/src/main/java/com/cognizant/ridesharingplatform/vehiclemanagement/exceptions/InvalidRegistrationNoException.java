package com.cognizant.ridesharingplatform.vehiclemanagement.exceptions;

public class InvalidRegistrationNoException extends Exception {

	public InvalidRegistrationNoException(String exception) {
		super(exception);
	}

}
