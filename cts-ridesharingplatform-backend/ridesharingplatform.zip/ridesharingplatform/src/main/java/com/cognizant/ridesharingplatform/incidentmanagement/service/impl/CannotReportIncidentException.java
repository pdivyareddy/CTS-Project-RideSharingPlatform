package com.cognizant.ridesharingplatform.incidentmanagement.service.impl;

public class CannotReportIncidentException extends Exception {
    public CannotReportIncidentException(String message) {
        super(message);
    }
}


