package com.cognizant.ridesharingplatform.vehiclemanagement.exceptions;

public class InvalidVehicleAgeException extends Exception {

	public InvalidVehicleAgeException(String exception) {
		super(exception);
	}

}
